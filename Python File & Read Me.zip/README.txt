Whilst our four datasets are submitted with the project the Python code itself is written such that it pulls raw data from our Github repository directly. This was acceptable according to Josh Burridge.

Our Github Repository Link:
https://github.com/mattshu0410/data-1002-project

To run the python project, the following libraries are required.

- Pandas
- Numpy
- Re
- Plotnine

There is also a line in the code which saves the merged data to a local directory on line 61. You will need to change the file path to that of your particular machine and uncomment it.